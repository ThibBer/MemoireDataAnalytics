package be.thibber.gamification;

import static org.junit.Assert.*;

public class CoordsTest {
    public void testGetDistanceTo(){
        assertThrows()
    }
}
