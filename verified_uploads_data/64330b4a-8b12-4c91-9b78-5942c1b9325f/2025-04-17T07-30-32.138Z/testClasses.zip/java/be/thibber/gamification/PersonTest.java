package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PersonTest {

    @Test
    public void getNameTest() {
        Person person = new Person("blessing");
        assertEquals("blessing", person.getName());
//        assertEquals(, example.sum(0, 0));
    }

}
