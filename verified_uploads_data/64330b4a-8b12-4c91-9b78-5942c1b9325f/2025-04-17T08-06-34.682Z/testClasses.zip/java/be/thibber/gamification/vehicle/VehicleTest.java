package be.thibber.gamification.vehicle;

import be.thibber.gamification.Coords;
import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class VehicleTest {

    @Test
    public void getVehicleTest() {
        Vehicle v1 = new Vehicle();
        Vehicle v2 = new Vehicle(30);

        assertEquals(0, 0.0,v1.getSpeed());
        assertEquals(30, 0.000001,v2.getSpeed());
    }

    @Test
    public void accelerateTest() {
        Vehicle v = new Vehicle(30);
        v.accelerate(20);
        assertEquals(50, 0.000001,v.getSpeed());
    }

    @Test
    public void brakeTest() {
        Vehicle v = new Vehicle(30);
        v.brake(20);
        assertEquals(10, 0.000001,v.getSpeed());
    }

    @Test
    public void iStoppedTest() {
        Vehicle v1 = new Vehicle();
        Vehicle v2 = new Vehicle(30);
        Vehicle v3 = new Vehicle(30);
        v3.reset();

        assertEquals(true, v1.isStopped());
        assertEquals(false, v2.isStopped());
        assertEquals(true, v3.isStopped());
    }

    @Test
    public void resetTest() {
        Vehicle v = new Vehicle(30);
        v.reset();
        assertEquals(0, 0.0,v.getSpeed());
    }
}
