package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import be.thibber.gamification.example.Example;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class CarTest {
    @Test
    public void addPassengerTest() {
        List<Person> passengers = new ArrayList<Person>();
        Person asher = new Person("Asher");
        Car car = new Car(20, 4);

        car.addPassenger(asher);
        assertFalse(car.getPassengers().isEmpty());
        assertTrue(car.getPassengers().contains(asher));
    }

    @Test
    public void removePassengerTest() {
        Person asher = new Person("Asher");
        Person blessing = new Person("blessing");
        List<Person> passengers = new ArrayList<Person>(){{
            add(asher);
            add(blessing);
        }};
        Car car = new Car(20, 4, passengers);

        car.removePassenger(asher);
        assertFalse(car.getPassengers().contains(asher));
    }

    @Test
    public void getPassengersTest() {
        Person asher = new Person("Asher");
        Person blessing = new Person("blessing");
        List<Person> passengers = new ArrayList<Person>(){{
            add(asher);
            add(blessing);
        }};
        Car car = new Car(20, 4, passengers);

        assertEquals(passengers, car.getPassengers());
    }

    @Test
    public void resetTest() {
        Person asher = new Person("Asher");
        Person blessing = new Person("blessing");
        List<Person> passengers = new ArrayList<Person>(){{
            add(asher);
            add(blessing);
        }};
        Car car = new Car(20, 4, passengers);

        car.reset();

        assertTrue(car.getPassengers().isEmpty());
        assertEquals(0, 0.0,car.getSpeed());

    }
}
