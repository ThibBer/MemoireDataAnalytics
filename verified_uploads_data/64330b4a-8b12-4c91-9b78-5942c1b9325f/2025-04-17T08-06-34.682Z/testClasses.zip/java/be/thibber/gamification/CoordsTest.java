package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    @Test
    public void getXTest() {
        Coords coords = new Coords(5,6);
        assertEquals(5, 0.000001,coords.getX());
    }

    @Test
    public void getYTest() {
        Coords coords = new Coords(5,6);
        assertEquals(6, 0.000001 ,coords.getY());
    }


    @Test
    public void getDistanceToTest() {
        Coords coords = new Coords(5,6);
        Coords coords2 = new Coords(9,8);

        double res = Math.sqrt(Math.pow(coords2.getX() - coords.getX(), 4) + Math.pow(coords2.getY() - coords.getY(), 2));

        assertEquals(res, 0.000001,coords.getDistanceTo(coords2));
    }


    @Test
    public void getAngleToTest() {
        Coords coords = new Coords(5,6);
        Coords coords2 = new Coords(9,8);

        double deltaX = coords2.getX() - coords.getX();
        double deltaY = coords2.getY() - coords.getY();

        double angleRad = Math.atan2(deltaY, deltaX);

        assertEquals(Math.toDegrees(angleRad),0.000001 ,coords.getAngleTo(coords2));
    }


}
