package be.thibber.gamification;

import be.thibber.gamification.example.Example;

import static org.junit.Assert.assertEquals;

public class RoadTest {

    public void getVehiclesTest() {
        Coords coords = new Coords(5,6);

        Example example = new Example();
        assertEquals(15, example.sum(10, 5));
        assertEquals(0, example.sum(0, 0));
    }

}
