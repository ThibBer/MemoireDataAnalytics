package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import java.awt.*;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class CarTest {
    private Car car;
    private Person person1;
    private Person person2;

    @BeforeEach
    public void setUp() {
        person1 = new Person("John Doe");
        person2 = new Person("Jane Doe");
        ArrayList<Person> passengers = new ArrayList<>();
        passengers.add(person1);
        car = new Car(50, 4, passengers);
    }

    @Test
    public void testConstructorWithSpeedSeatsAndPassengers() {
        assertEquals(50, car.getSpeed());
        assertEquals(4, car.getSeatsCount());
        assertEquals(1, car.getPassengers().size());
    }

    @Test
    public void testConstructorWithSeats() {
        Car car = new Car(4);
        assertEquals(0, car.getSpeed());
        assertEquals(4, car.getSeatsCount());
    }

    @Test
    public void testConstructorWithSpeedAndSeats() {
        Car car = new Car(50, 4);
        assertEquals(50, car.getSpeed());
        assertEquals(4, car.getSeatsCount());
        assertEquals(1, car.getPassengers().size());
    }

    @Test
    public void testAddPassenger() {
        car.addPassenger(person2);
        assertEquals(2, car.getPassengers().size());
        assertTrue(car.getPassengers().contains(person2));
    }

    @Test
    public void testRemovePassenger() {
        car.removePassenger(person1);
        assertEquals(0, car.getPassengers().size());
    }

    @Test
    public void testSetSpeed() {
        car.setSpeed(60);
        assertEquals(60, car.getSpeed());
    }

    @Test
    public void testReset() {
        car.reset();
        assertEquals(0, car.getSpeed());
        assertTrue(car.getPassengers().isEmpty());
    }

    @Test
    public void testSetSeatsCount() {
        car.setSeatsCount(5);
        assertEquals(5, car.getSeatsCount());
    }

    @Test
    public void testSetPassengers() {
        ArrayList<Person> newPassengers = new ArrayList<>();
        newPassengers.add(person2);
        car.setPassengers(newPassengers);
        assertEquals(1, car.getPassengers().size());
        assertTrue(car.getPassengers().contains(person2));
    }
}
