package be.thibber.gamification.exceptions;

public class FullParkingException extends Exception {
    public FullParkingException(String message) {
        super(message);
    }
}
