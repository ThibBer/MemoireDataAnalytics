package be.thibber.gamification.vehicle;

import be.thibber.gamification.example.Example;
import org.junit.Test;

public class VehicleTest {
    @Test
    public void vehicleTest() {
    Example example = new Example();
    }