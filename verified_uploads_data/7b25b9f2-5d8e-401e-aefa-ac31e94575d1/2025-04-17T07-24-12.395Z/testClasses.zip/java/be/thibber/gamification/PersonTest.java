package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class PersonTest {
    @Test
    public void testPerson() {
        Person person = new Person("John Doe");
        assertEquals("John Doe", person.getName());
        person.setName("Jane Doe");
        assertEquals("Jane Doe", person.getName());
    }
}
