package be.thibber.gamification.vehicle;

import org.junit.Test;
import static org.junit.Assert.*;

public class VehicleTest {

    @Test
    public void testVehicleInitialisation() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void getSpeedTest() {
        Vehicle vehicle = new Vehicle(50);
        assertEquals(50, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void setSpeedTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.setSpeed(30);
        assertEquals(30, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void testVehiculeConstructorWithNegativeSpeed() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Vehicle(-10);
        });
    }

    @Test
    public void testSetSpeedWithNegativeValue() {
        Vehicle vehicle = new Vehicle();
        assertThrows(IllegalArgumentException.class, () -> {
            vehicle.setSpeed(-20);
        });
    }

    @Test
    public void accelerateTest() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.accelerate(20);
        assertEquals(70, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void accelerateTestWithNegativeArgument() {
        Vehicle vehicle = new Vehicle(50);
        assertThrows(IllegalArgumentException.class, () -> vehicle.accelerate(-20));
    }

    @Test
    public void brakeTest() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.brake(20);
        assertEquals(30, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void brakeTestWithNegativeArgument() {
        Vehicle vehicle = new Vehicle(50);
        assertThrows(IllegalArgumentException.class, () -> vehicle.brake(-20));
    }

    @Test
    public void brakeTestWithExcessiveDecrement() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.brake(60);
        assertEquals(0, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void testisStoppedConstructor() {
        Vehicle vehicle = new Vehicle();
        assertTrue(vehicle.isStopped());
    }

    @Test
    public void testisStoppedSetSpeedZero() {
        Vehicle vehicle = new Vehicle(0);
        assertTrue(vehicle.isStopped());
    }

    @Test
    public void testisStoppedBrake() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.brake(50);
        assertTrue(vehicle.isStopped());
    }

    @Test
    public void testisNotStopped() {
        Vehicle vehicle = new Vehicle(50);
        assertFalse(vehicle.isStopped());
    }

    @Test
    public void testResetSpeed() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.reset();
        assertEquals(0, vehicle.getSpeed(), 0.001);
    }

    @Test
    public void testResetSpeedWithAccelerate() {
        Vehicle vehicle = new Vehicle(50);
        vehicle.reset();
        vehicle.accelerate(50);
        assertNotEquals(0, vehicle.getSpeed(), 0.001);
    }

}