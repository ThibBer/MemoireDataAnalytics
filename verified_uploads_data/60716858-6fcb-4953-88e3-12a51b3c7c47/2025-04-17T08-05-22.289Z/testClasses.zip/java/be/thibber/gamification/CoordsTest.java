package be.thibber.gamification;

import org.junit.Test;

public class CoordsTest {
    @Test
    public void getXTest() {
        Coords coords = new Coords(5, 0);
        assert (coords.getX() == 5);
    }
    @Test
    public void getYTest() {
        Coords coords = new Coords(0, 5);
        assert (coords.getY() == 5);
    }
    @Test
    public void setXTest() {
        Coords coords = new Coords(0, 0);
        coords.setX(2);
        assert (coords.getX() == 2);
    }
    @Test
    public void setYTest() {
        Coords coords = new Coords(0, 0);
        coords.setY(2);
        assert (coords.getY() == 2);
    }
    @Test
    public void getDistanceToTest() {
        Coords coords = new Coords(8, 4);
        Coords other = new Coords(4, 2);
        assert (coords.getDistanceTo(other)==67600);
    }
}