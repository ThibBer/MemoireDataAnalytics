package be.thibber.gamification;

import be.thibber.gamification.vehicle.Vehicle;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RoadTest {

    @Test
    public void constructor() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);
        assertTrue(road instanceof Road);
    }

    @Test
    public void getVehicles() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);

        assertEquals(vehicles, road.getVehicles());
    }

    @Test
    public void addVehicles() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);

        road.addVehicle(new Vehicle(60));
        vehicles.add(new Vehicle(60));

        assertEquals(vehicles, road.getVehicles());
    }

    @Test
    public void removeVehicles() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);

        road.removeVehicle(new Vehicle(50));
        vehicles.remove(new Vehicle(50));

        assertEquals(vehicles, road.getVehicles());
    }

    @Test
    public void getName() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);

        assertEquals("Road", road.getName());
    }

    @Test
    public void setName() {
        List<Coords> points = new ArrayList<Coords>();
        points.add(new Coords(0, 0));
        points.add(new Coords(1, 0));
        points.add(new Coords(2, 0));

        List<Vehicle> vehicles = new ArrayList<>();
        vehicles.add(new Vehicle(40));
        vehicles.add(new Vehicle(50));

        Road road = new Road("Road", points, vehicles);
        road.setName("Road2");

        assertEquals("Road2", road.getName());
    }
}
