package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.*;


public class VehicleTest {

    @Test
    public void constructor() {
        Vehicle vehicle = new Vehicle(2);

        assertTrue(vehicle instanceof Vehicle);
    }

    @Test
    public void constructor2() {
        Vehicle vehicle = new Vehicle();

        assertTrue(vehicle instanceof Vehicle);
    }

    @Test
    public void constructorError() {
        assertThrows(IllegalArgumentException.class, () -> { new Vehicle(-2); });
    }

    @Test
    public void getSpeed() {
        Vehicle vehicle = new Vehicle(2);
        assertEquals(2, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void setSpeed() {
        Vehicle vehicle = new Vehicle(2);
        vehicle.setSpeed(5);
        assertEquals(5, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void accelerate() {
        Vehicle vehicule = new Vehicle(2);
        vehicule.accelerate(4);

        assertEquals(6, vehicule.getSpeed(), 0.01);
    }

    @Test
    public void accelerateError() {
        Vehicle vehicule = new Vehicle(2);

        assertThrows(IllegalArgumentException.class, () -> { vehicule.accelerate(-5); });
    }

    @Test
    public void brake() {
        Vehicle vehicule = new Vehicle(6);
        vehicule.brake(4);

        assertEquals(2, vehicule.getSpeed(), 0.01);
    }

    @Test
    public void brakeError() {
        Vehicle vehicule = new Vehicle(2);

        assertThrows(IllegalArgumentException.class, () -> { vehicule.brake(-5); });
    }

    @Test
    public void isStopped() {
        Vehicle vehicle = new Vehicle(2);
        assertFalse(vehicle.isStopped());
        vehicle.setSpeed(0);
        assertTrue(vehicle.isStopped());
    }

    @Test
    public void reset() {
        Vehicle vehicle = new Vehicle(2);
        vehicle.reset();
        assertTrue(vehicle.isStopped());
    }
}
