package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class CarTest {

    @Test
    public void constructor() {
        Person person = new Person("Test");
        List<Person> people = new ArrayList<>();
        people.add(person);
        Car car = new Car(30, 4, people);
        assertTrue(car instanceof Car);
    }

    @Test
    public void constructor2() {
        Car car = new Car(30, 4);
        assertTrue(car instanceof Car);
    }

    @Test
    public void constructor3() {
        Car car = new Car(4);
        assertTrue(car instanceof Car);
    }
}
