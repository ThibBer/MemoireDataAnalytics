package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.*;


public class VehicleTest {

    @Test
    public void constructor() {
        Vehicle vehicle = new Vehicle(2);

        assertTrue(vehicle instanceof Vehicle);
    }

    @Test
    public void constructor2() {
        Vehicle vehicle = new Vehicle();

        assertTrue(vehicle instanceof Vehicle);
    }

    @Test
    public void constructorError() {
        assertThrows(IllegalArgumentException.class, () -> { new Vehicle(-2); });
    }

    @Test
    public void getSpeed() {
        Vehicle vehicle = new Vehicle(2);
        assertEquals(2, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void setSpeed() {
        Vehicle vehicle = new Vehicle(2);
        vehicle.setSpeed(5);
        assertEquals(5, vehicle.getSpeed(), 0.01);
    }
}
