package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CoordsTest {

    @Test
    public void constructor() {
        Coords coords = new Coords(2, 4);
        assertTrue(coords instanceof Coords);
    }

    @Test
    public void getX() {
        Coords coords = new Coords(2, 4);
        assertEquals(2, coords.getX(), 0.01);
    }

    @Test
    public void getY() {
        Coords coords = new Coords(2, 4);
        assertEquals(4, coords.getY(), 0.01);
    }

    @Test
    public void setX() {
        Coords coords = new Coords(2, 4);
        coords.setX(5.5);
        assertEquals(5.5, coords.getX(), 0.01);
    }

    @Test
    public void setY() {
        Coords coords = new Coords(2, 4);
        coords.setY(6.1);
        assertEquals(6.1, coords.getY(), 0.01);
    }

    @Test
    public void getDistanceTo() {
        Coords coords1 = new Coords(2, 4);
        Coords coords2 = new Coords(6, 6);

        assertEquals(16.12, coords1.getDistanceTo(coords2), 0.01);
    }

    @Test
    public void getAngleTo() {
        Coords coords1 = new Coords(2, 4);
        Coords coords2 = new Coords(6, 6);
        assertEquals(68.19, coords1.getAngleTo(coords2), 0.01);
    }

    @Test
    public void move() {
        Coords coords = new Coords(2, 4);
        coords.move(3,2);
        assertEquals(5, coords.getX(), 0.01);
        assertEquals(2, coords.getY(), 0.01);
    }
}
