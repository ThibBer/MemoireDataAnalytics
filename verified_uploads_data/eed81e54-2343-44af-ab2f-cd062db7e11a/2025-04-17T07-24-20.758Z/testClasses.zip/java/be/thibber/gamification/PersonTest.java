package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PersonTest {

    @Test
    public void getName() {
        Person person = new Person("Test");

        assertEquals("Test", person.getName());
    }

    @Test
    public void setName() {
        Person person = new Person("Test");
        person.setName("Test2");
        assertEquals("Test2", person.getName());
    }

    @Test
    public void constructor() {
        Person person = new Person("Test");
        assertTrue(person instanceof Person);
    }
}
