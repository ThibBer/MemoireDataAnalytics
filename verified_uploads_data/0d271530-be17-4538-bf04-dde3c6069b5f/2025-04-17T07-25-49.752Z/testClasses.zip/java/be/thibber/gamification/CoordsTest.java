package be.thibber.gamification;

import org.junit.Test;

public class CoordsTest {

    @Test
    public void gettersTest() {
        Coords coords = new Coords(1, 2);
        assert coords.getX() == 1;
        assert coords.getY() == 2;
    }

    @Test
    public void settersTest() {
        Coords coords = new Coords(1, 2);
        coords.setX(3);
        coords.setY(4);
        assert coords.getX() == 3;
        assert coords.getY() == 4;
    }

    @Test
    public void getDistanceTest() {
        Coords coords1 = new Coords(1, 2);
        Coords coords2 = new Coords(3, 4);
        double distance = coords1.getDistanceTo(coords2);
        assert distance == Math.sqrt(20);;
    }

    @Test
    public void getDistanceWithNegativeCoordTest() {
        Coords coords1 = new Coords(-1, -2);
        Coords coords2 = new Coords(3, 4);
        double distance = coords1.getDistanceTo(coords2);
        assert distance == Math.sqrt(64*4 + 36);;
    }

    @Test
    public void moveTest() {
        Coords coords = new Coords(1, 2);
        coords.move(3, 4);
        assert coords.getX() == 4;
        assert coords.getY() == -2;
    }

    @Test
    public void getAngleTest() {
        Coords coords1 = new Coords(1, 2);
        Coords coords2 = new Coords(3, 4);

        double angle = coords1.getAngleTo(coords2);
        assert angle == Math.toDegrees(Math.atan2(6, 2));
    }
}
