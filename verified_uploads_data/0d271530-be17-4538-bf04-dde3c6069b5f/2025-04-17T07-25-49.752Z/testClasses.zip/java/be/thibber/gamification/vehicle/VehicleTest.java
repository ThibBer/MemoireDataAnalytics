package be.thibber.gamification.vehicle;

import org.junit.Test;

public class VehicleTest {

    @Test
    public void vehicleConstructorTest() {
        Vehicle vehicle = new Vehicle(10);
        assert vehicle.getSpeed() == 10;
    }

    @Test
    public void vehicleDefaultConstructorTest() {
        Vehicle vehicle = new Vehicle();
        assert vehicle.getSpeed() == 0;
    }

    @Test
    public void vehicleConstructorNegativeSpeedTest() {
        try {
            Vehicle vehicle = new Vehicle(-10);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    public void vehicleSetSpeedTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.setSpeed(20);
        assert vehicle.getSpeed() == 20;
    }

    @Test
    public void vehicleSetSpeedNegativeTest() {
        Vehicle vehicle = new Vehicle();
        try {
            vehicle.setSpeed(-10);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    public void accelerateDefaultTest() {
        Vehicle vehicle = new Vehicle(10);
        vehicle.accelerate(10);
        assert vehicle.getSpeed() == 20;
    }

    @Test
    public void accelerateNegativeTest() {
        Vehicle vehicle = new Vehicle(10);
        try {
            vehicle.accelerate(-10);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    public void brakeDefaultTest() {
        Vehicle vehicle = new Vehicle(20);
        vehicle.brake(10);
        assert vehicle.getSpeed() == 10;
    }

    @Test
    public void brakeNegativeTest() {
        Vehicle vehicle = new Vehicle(20);
        try {
            vehicle.brake(-10);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    public void brakeBelowZeroTest() {
        Vehicle vehicle = new Vehicle(20);
        vehicle.brake(30);
        assert vehicle.getSpeed() == 0;
    }

    @Test
    public void isStoppedTest() {
        Vehicle vehicle = new Vehicle(0);
        assert vehicle.isStopped();
    }

    @Test
    public void isNotStoppedTest() {
        Vehicle vehicle = new Vehicle(10);
        assert !vehicle.isStopped();
    }

    @Test
    public void resetTest() {
        Vehicle vehicle = new Vehicle(10);
        vehicle.reset();
        assert vehicle.getSpeed() == 0;
    }

}
