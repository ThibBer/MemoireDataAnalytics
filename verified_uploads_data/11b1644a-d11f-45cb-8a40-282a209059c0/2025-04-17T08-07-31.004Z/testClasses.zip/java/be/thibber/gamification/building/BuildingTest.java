package be.thibber.gamification.building;

import org.junit.Assert;
import org.junit.Test;

public class BuildingTest {
    @Test
    public void test_building() {
        House h = new House("Rue", 10.0, 5.0);

        double s = h.getTotalSurface();

        Assert.assertEquals(s, 50.0,0.0);

    }
}
