package be.thibber.gamification;

import org.junit.Assert;
import org.junit.Test;

public class CoordsTest {

    @Test
    public void test_coord() {
        Coords c = new Coords(1.0, 2.0);
        Assert.assertEquals(1.0, c.getX(), 0.1);
        Assert.assertEquals(2.0, c.getY(), 0.1);
    }

    @Test
    public void test_set_x_coord() {
        Coords c = new Coords(1.0, 2.0);

        c.setX(3.0);

        Assert.assertEquals(3.0, c.getX(), 0.1);
    }

    @Test
    public void test_set_y_coord() {
        Coords c = new Coords(1.0, 2.0);

        c.setY(4.0);

        Assert.assertEquals(4.0, c.getY(),0.1);
    }

    @Test
    public void test_distance_01() {
        Coords c = new Coords(1.0, 2.0);
        double d = c.getDistanceTo(new Coords(1.0, 2.0));

        Assert.assertEquals(0.0, d, 0.1);
    }

    @Test
    public void test_distance_02() {
        Coords c = new Coords(0.0, 0.0);
        double d = c.getDistanceTo(new Coords(0.0, 1.0));

        Assert.assertEquals(1.0, d, 0.1);
    }

    @Test
    public void test_move_01() {
        Coords c = new Coords(1.0, 2.0);
        c.move(2.0,1.0);

        Assert.assertEquals(3.0, c.getX(), 0.1);
        Assert.assertEquals(3.0, c.getY(), 0.1);
    }

    @Test
    public void test_angle_01() {
        Coords c = new Coords(1.0, 2.0);
        double d = c.getAngleTo(new Coords(1.0, 2.0));

        Assert.assertEquals(90.0, d, 0.1);
    }
}
