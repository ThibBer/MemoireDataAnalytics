package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertThrows;

public class CarTest {
    @Test
    public void test() {
        Car c = new Car(10);

        int n = c.getSeatsCount();

        Assert.assertEquals(10, n);
    }

    @Test
    public void test_set_count() {
        Car c = new Car(10);

        c.setSeatsCount(15);
        int n = c.getSeatsCount();

        Assert.assertEquals(15, n);
    }

    @Test
    public void test_set_count_zero() {
        Car c = new Car(10);

        c.setSeatsCount(0);
        int n = c.getSeatsCount();

        Assert.assertEquals(0, n);
    }

    @Test
    public void test_set_count_netagive() {
        Car c = new Car(10);

        c.setSeatsCount(-10);
        int n = c.getSeatsCount();

        Assert.assertEquals(-10, n);
    }

    @Test
    public void test_passenger() {
        Car c = new Car(10);

        int n = c.getPassengers().size();

        Assert.assertEquals(0, n);
    }

    @Test
    public void test_add_passenger() {
        Car c = new Car(10);

        c.addPassenger(new Person("Hugo"));

        int n = c.getPassengers().size();

        Assert.assertEquals(1, n);
    }

    @Test
    public void test_add_passenger_to_limit() {
        Car c = new Car(1);

        c.addPassenger(new Person("Hugo"));

        int n = c.getPassengers().size();

        Assert.assertEquals(1, n);
    }

    @Test
    public void test_add_passenger_over_limit() {
        Car c = new Car(1);

        c.addPassenger(new Person("Hugo"));

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            c.addPassenger(new Person("Max"));
        });

        Assert.assertTrue(exception.getMessage().contains("No more seats available"));
    }

    @Test
    public void test_add_null_passenger() {
        Car c = new Car(1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            c.addPassenger(null);
        });

        Assert.assertTrue(exception.getMessage().contains("Person cannot be null"));
    }

    @Test
    public void test_remove_passenger() {
        Person p = new Person("Hugo");
        Car c = new Car(10, 1, List.of(p));

        c.removePassenger(p);

        int n = c.getPassengers().size();

        Assert.assertEquals(0, n);
    }

    @Test
    public void test_remove_passenger_unknown() {
        Person p = new Person("Hugo");
        Car c = new Car(10, 1, List.of(p));

        c.removePassenger(new Person("Lola"));

        int n = c.getPassengers().size();

        Assert.assertEquals(1, n);
    }

    @Test
    public void test_remove_null_passenger() {
        Car c = new Car(1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            c.addPassenger(null);
        });

        Assert.assertTrue(exception.getMessage().contains("Person cannot be null"));
    }
}
