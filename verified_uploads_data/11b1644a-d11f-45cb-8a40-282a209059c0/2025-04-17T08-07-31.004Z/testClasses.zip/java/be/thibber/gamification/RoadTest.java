package be.thibber.gamification;

import be.thibber.gamification.vehicle.Vehicle;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

public class RoadTest {
    @Test
    public void test_road() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));
        Assert.assertEquals("Yo", r.getName());
    }

    @Test
    public void test_road_set_name() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));
        r.setName("Oy");

        Assert.assertEquals("Oy", r.getName());
    }

    @Test
    public void test_road_set_name_empty() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));
        r.setName("");

        Assert.assertEquals("", r.getName());
    }

    @Test
    public void test_road_set_name_null() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));
        r.setName(null);

        Assert.assertEquals(null, r.getName());
    }

    @Test
    public void test_road_add_vehicle_01() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));
        r.addVehicle(new Vehicle());

        Assert.assertEquals(2, r.getVehicles().size());
    }

    @Test
    public void test_road_add_vehicle_02() {
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(new Vehicle()));

        r.addVehicle(new Vehicle());
        r.addVehicle(new Vehicle());

        Assert.assertEquals(3, r.getVehicles().size());
    }

    @Test
    public void test_road_remove_vehicle_01() {
        Vehicle v = new Vehicle();
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(v));

        r.removeVehicle(v);

        Assert.assertEquals(0, r.getVehicles().size());
    }

    @Test
    public void test_road_remove_vehicle_twice() {
        Vehicle v = new Vehicle();
        Road r = new Road("Yo", List.of(new Coords(1,2), new Coords(3,2)), List.of(v));

        r.removeVehicle(v);
        r.removeVehicle(v);

        Assert.assertEquals(0, r.getVehicles().size());
    }
}
