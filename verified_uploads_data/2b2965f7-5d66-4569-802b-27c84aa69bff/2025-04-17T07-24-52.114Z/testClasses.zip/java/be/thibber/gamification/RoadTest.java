package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class RoadTest {
    @Test
    public void testroad() {
        Example example = new Example();

    }
}
