package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void coordTest() {
        Coords coords = new Coords(10, 5);
        assertEquals(coords.getX(), 10.0, 0.0);
        assertEquals(coords.getY(), 5.0, 0.0);
    }



}
