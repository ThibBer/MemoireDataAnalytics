package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CarTest {

    Car c = new Car(4);

    @Test
    public void test() {

        assertEquals(4,c.getSeatsCount(),0.001);


    }
    @Test
    public void test2() {
        c.setSpeed(3.4);
        c.setSeatsCount(2);

        assertEquals( 3.4, c.getSpeed(),0.001);
        assertEquals(2 , c.getSeatsCount(),0.001);


    }
}

