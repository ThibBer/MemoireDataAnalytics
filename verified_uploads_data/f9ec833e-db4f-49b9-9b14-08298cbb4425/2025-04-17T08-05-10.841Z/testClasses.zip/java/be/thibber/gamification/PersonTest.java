package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PersonTest {
    Person pers = new Person("test" );

    @Test
    public void PersonTest1() {
        pers.setName("test56");
        assertEquals("test56",pers.getName());
    }
    @Test
    public void test() {

        assertEquals("test",pers.getName());


    }
}
