package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    Coords coord = new Coords(22.0,5.0);

    @Test
    public void test() {

        assertEquals(22.0,coord.getX(), 0);
        assertEquals(5.0,coord.getY(),0);
        assertEquals(5.6,coord.getY(),0);



    }

    @Test
    public void test2() {

        assertEquals(17.0,coord.getDistanceTo(new Coords(22.0,5.0)), 0);




    }




}
