package be.thibber.gamification.vehicle;

import be.thibber.gamification.Road;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class VehicleTest {
    Vehicle v2 = new Vehicle(3.4);

    @Test
    public void test() {
        Vehicle v = new Vehicle(3.4);

        assertEquals(3.4,v.getSpeed(),0.001);


    }
    @Test
    public void test2() {
        v2.setSpeed(2.2);

        assertEquals( 2.2, v2.getSpeed(),0.001);


    }
}
