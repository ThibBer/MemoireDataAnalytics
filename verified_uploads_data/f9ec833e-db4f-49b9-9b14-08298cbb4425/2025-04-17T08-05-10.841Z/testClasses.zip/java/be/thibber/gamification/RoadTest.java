package be.thibber.gamification;

import be.thibber.gamification.building.Building;
import be.thibber.gamification.building.BuildingTest;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class RoadTest {
    Coords e = new Coords(0,0);
    Coords r = new Coords(4.5,6.8);

    List<Coords> c = new ArrayList<Coords>();

    Road road = new Road("test", c, null );

    @Test
    public void test() {
        Road road = new Road("test", null , null );

        assertEquals("test",road.vehicles);


    }

    @Test
    public void test2() {
         road.setName("test2");
        assertEquals("test2",road.vehicles,0);
        assertEquals("test2",road.getName());


    }

    @Test
    public void test3() {
        assertEquals("test",road.getName());


    }




}
