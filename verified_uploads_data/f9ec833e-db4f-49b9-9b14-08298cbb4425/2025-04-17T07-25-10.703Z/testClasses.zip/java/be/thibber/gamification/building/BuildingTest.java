package be.thibber.gamification.building;


import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BuildingTest {
    static class TestBuilding extends Building {
        public TestBuilding(String address, double groundSurface, double floorsCount) {
            super(address, groundSurface, floorsCount);
        }
    }

    @Test
    public void BuildingTest1() {
        Building building = new TestBuilding("123 Main St", 200.5, 3);

        assertEquals("123 Main St",building.getAddress());
        assertEquals(200.5,building.getGroundSurface());
        assertEquals(3,building.getFloorsCount());
    }

    @Test
    public void testSetFloorsCountValid() {
        Building building = new TestBuilding("Address", 100, 2);
        building.setFloorsCount(5);

        assertEquals(5, building.getFloorsCount());
    }






}
