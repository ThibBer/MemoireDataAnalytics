package be.thibber.gamification;

import org.junit.Test;

public class RoadTest {

    @Test
    public void test() {

    }


}
