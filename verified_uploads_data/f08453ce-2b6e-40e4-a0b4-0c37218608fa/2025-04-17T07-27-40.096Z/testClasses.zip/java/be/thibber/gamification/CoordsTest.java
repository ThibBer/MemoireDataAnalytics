package be.thibber.gamification;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;



public class CoordsTest {

    @Test
    public void move() {

    }

    @Test
     public void testgetdistanceto(){

    }

    @Test
    public void testangle(){
        Coords c1 = new Coords(2, 4);
        Coords c2 = new Coords(3, 12);
        assertEquals(86.42366562500266, c1.getAngleTo(c2), 0.0001);
        assertEquals(93.57633437499736, c2.getAngleTo(c1), 0.0001);


    }




}