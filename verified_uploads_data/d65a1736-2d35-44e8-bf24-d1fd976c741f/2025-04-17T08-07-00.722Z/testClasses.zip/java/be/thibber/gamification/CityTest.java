package be.thibber.gamification;
import be.thibber.gamification.building.Building;
import be.thibber.gamification.building.Parking;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CityTest {

    static class TestBuilding extends Building {
        public TestBuilding(String address, double surface, double floors) {
            super(address, surface, floors);
        }
    }
    static class TestParking extends Parking {
        private int capacity;
        private int available;

        public TestParking(String address, double surface, double floors, int capacity, int available) {
            super(address, surface, capacity);
            this.capacity = capacity;
            this.available = available;
        }
        @Override
        public int getCapacity() {
            return capacity;
        }

        @Override
        public int getAvailableSpots() {
            return available;
        }
    }

    private City city = new City(new ArrayList<>(), new ArrayList<>());

    @Test
    public void testAddAndRemoveBuilding() {
        Building b = new TestBuilding("Rue de Bruxelles", 50, 2);
        city.addBuilding(b);
        assertEquals(1, city.countBuildingByType(Building.class));
        assertTrue(city.removeBuilding(b));
        assertEquals(0, city.countBuildingByType(Building.class));
    }

    @Test
    public void testAddRemoveRoad() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        Road road = new Road("Rue 1", List.of(new Coords(0, 0), new Coords(1, 1)), new ArrayList<>());
        city.addRoad(road);
        assertEquals(1, city.getAverageRoadLength() > 0 ? 1 : 0); // moyenne non nul
        city.removeRoad(road);
    }

    @Test
    public void testBuildingsSurface() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        city.addBuilding(new TestBuilding("B1", 100, 1));
        city.addBuilding(new TestBuilding("B2", 50, 1));
        assertEquals(150, city.getBuildingsGroundSurface(), 0.001);
    }

    @Test
    public void testCountParking() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        city.addBuilding(new TestParking("P1", 10, 1, 20, 10));
        city.addBuilding(new TestBuilding("B1", 30, 1));
        assertEquals(1, city.countBuildingByType(Parking.class));
    }

    @Test
    public void testAvailableParkingSlots() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        city.addBuilding(new TestParking("P1", 10, 1, 10, 6));
        city.addBuilding(new TestParking("P2", 15, 1, 20, 15));
        assertEquals(21, city.getAvailableParkingSlotsCount());
    }

    @Test
    public void testParkingUsagePercentage() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        city.addBuilding(new TestParking("P1", 10, 1, 10, 6)); // utilisé : 4
        city.addBuilding(new TestParking("P2", 15, 1, 20, 10)); // utilisé : 10
        // total utilisé = 14, total capacité = 30, % = 46.66
        assertEquals(46.66, city.getParkingsUsagePercentage(), 0.01);
    }

    @Test
    public void testAverageRoadLength() {
        City city = new City(new ArrayList<>(), new ArrayList<>());
        Road r1 = new Road("R1", List.of(new Coords(0, 0), new Coords(3, 4)), new ArrayList<>()); // longueur 5
        Road r2 = new Road("R2", List.of(new Coords(0, 0), new Coords(0, 1)), new ArrayList<>()); // longueur 1
        city.addRoad(r1);
        city.addRoad(r2);
        assertEquals(3.0, city.getAverageRoadLength(), 0.01);
    }






}
