package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void distanceTest() {
        Coords coo = new Coords(15, 0);
        Coords example = new Coords(15, 12);
        System.out.println(coo.getDistanceTo(coo));
        Double distance = 0.0;
        assertEquals(0.0, coo.getDistanceTo(example));

        //assertEquals(0, example.sum(0, 0));
    }

    @Test
    public void angleTest() {
        Coords coo = new Coords(15, 0);
        Coords example = new Coords(15, 12);
        System.out.println(coo.getAngleTo(example));
        assertEquals(0.0, coo.getDistanceTo(example));

        //assertEquals(0, example.sum(0, 0));
    }
}
