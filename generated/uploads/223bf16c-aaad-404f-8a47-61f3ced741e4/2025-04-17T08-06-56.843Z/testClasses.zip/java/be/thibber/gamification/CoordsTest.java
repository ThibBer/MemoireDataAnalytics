package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class CoordsTest {

    @Test
    public void getXTest() {
        Coords coords = new Coords(1.0, 1.0);
        assertEquals(1.0, coords.getX(), 0.0);
    }

    @Test
    public void getYTest() {
        Coords coords = new Coords(2.0, 3.0);
        assertEquals(3.0, coords.getY(), 0.0);
    }

    @Test
    public void setXTest(){

        Coords coords = new Coords(1.0, 1.0);
        coords.setX(2.0);
        assertEquals(2.0, coords.getX(), 0.0);

    }

    @Test
    public void setYTest(){
        Coords coords = new Coords(2.0, 3.0);
        coords.setY(5.7);
        assertEquals(5.7, coords.getY(), 0.0);
    }

    @Test
    public void moveTest(){
        Coords coords = new Coords(3.0, 4.0);
        coords.move(1.0, 1.0);
        assertEquals(4.0, coords.getX(), 0.0);
        assertEquals(5.0, coords.getY(), 0.0);

    }




}
