package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PersonTest {

    @Test
    public void getNameTest(){
        Person person = new Person("John");
        assertEquals("John", person.getName());

    }

    @Test
    public void setNameTest(){
        Person person = new Person("John");
        person.setName("Doe");
        assertEquals("Doe", person.getName());

    }
}
