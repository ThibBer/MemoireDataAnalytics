package be.thibber.gamification.vehicle;

public class VehicleTest {
}
