package be.thibber.gamification.building;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class BuildingTest {

    @Test
    public void getAddressTest(){

        Building building1 = new Building("Open Sreet Map", 1800.0, 58.0) {
            @Override
            public String getAddress() {
                return super.getAddress();
            }
        };

        assertEquals("Open Street Map", building1.getAddress());

    }




}