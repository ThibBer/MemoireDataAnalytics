package be.thibber.gamification;

import org.junit.Test;



public class PolyLineTest {

    @Test
    public void getLengthTest(){

    }

    @Test
    public void getPointsTest(){

    }

    @Test
    public void setPointsTest(){

    }

    @Test
    public void appendPointTest(){

    }

    @Test
    public void getMaximumSegmentLengthTest(){

    }

    @Test
    public void moveTest(){

    }

}


