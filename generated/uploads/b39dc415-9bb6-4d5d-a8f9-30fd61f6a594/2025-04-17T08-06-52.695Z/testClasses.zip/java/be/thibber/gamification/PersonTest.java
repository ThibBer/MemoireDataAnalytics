package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {
    @Test
    public void testPerson() {
        Person person = new Person("Alice");
        assert person.getName().equals("Alice");

        Person person2 = new Person("Bob");
        assert person2.getName().equals("Bob");

        Person person3 = new Person("Charlie");
        assert person3.getName().equals("Charli");
    }

}
