package be.thibber.gamification;

import be.thibber.gamification.vehicle.Vehicle;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class RoadTest {
    @Test
    public void roadTest() {
        List<Vehicle> vehicles = new ArrayList<Vehicle>();
        
    }
}
