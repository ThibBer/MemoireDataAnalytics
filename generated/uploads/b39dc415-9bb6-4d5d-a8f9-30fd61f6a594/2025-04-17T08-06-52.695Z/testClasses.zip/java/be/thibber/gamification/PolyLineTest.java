package be.thibber.gamification;

import org.junit.Test;

public class PolyLineTest {
    @Test
    public void polyTest(){

    }
}
