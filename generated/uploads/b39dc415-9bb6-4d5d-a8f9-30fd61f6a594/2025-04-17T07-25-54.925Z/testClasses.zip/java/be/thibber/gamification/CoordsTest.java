package be.thibber.gamification;

import org.junit.Test;

public class CoordsTest {
    @Test
    public void coordTest() {
        Coords coords = new Coords(0, 0);
        assert coords.getX() == 0;
        assert coords.getY() == 0;
    }
}
