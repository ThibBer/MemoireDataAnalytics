package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {

}
