package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void distanceTest() {
        Coords coo = new Coords(15, 0);
        Coords example = new Coords(15, 0);
        System.out.println(coo.getDistanceTo(coo));
        Double distance = 0.0;
        assertEquals(0.0, coo.getDistanceTo(example),0.000000001);

        //assertEquals(0, example.sum(0, 0));
    }

    @Test
    public void angleTest() {
        Coords coo = new Coords(15, 0);
        Coords example = new Coords(15, 0);
        //coo.getDistanceTo(example);
        assertEquals(0.0, coo.getDistanceTo(example),0.000000001);
    }

    @Test
    public void returnValueTest() {
        Coords coo = new Coords(15, 7);
        assertEquals(15, coo.getX(),0.000000001);
        assertEquals(7, coo.getY(),0.000000001);

    }
    @Test
    public void setValueTest() {
        Coords coo = new Coords(15, 7);
        coo.setX(20);
        coo.setY(99);
        assertEquals(20.0, coo.getX(),0.000000001);
        assertEquals(99.0, coo.getY(), 0.000000001);
    }
    @Test
    public void moveValueTest() {
        Coords coo = new Coords(15, 10);
        coo.move(20.0,6.0);
        assertEquals(35.0, coo.getX(), 0.000000001);
        assertEquals(4.0, coo.getY(), 0.000000001);
    }
}
