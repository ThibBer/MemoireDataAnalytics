package be.thibber.gamification;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

public class PolyLineTest {
    @Test public void LenTest() {
        Coords point1 = new Coords(0, 0);
        Coords point2 = new Coords(1, 1);
        PolyLine points = new PolyLine(point1, point2);
        points.appendPoint(new Coords(0, 0));
        points.appendPoint(new Coords(1, 1));

        assertEquals(2.0,points.getLength(),0.00001);

    }
}
