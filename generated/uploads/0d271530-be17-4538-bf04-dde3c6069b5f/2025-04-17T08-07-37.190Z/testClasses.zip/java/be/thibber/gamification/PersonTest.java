package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {

    @Test
    public void getNameTest() {
        Person person = new Person("John");
        assert person.getName().equals("John");
    }

    @Test
    public void setNameTest() {
        Person person = new Person("John");
        person.setName("Doe");
        assert person.getName().equals("Doe");
    }
}
