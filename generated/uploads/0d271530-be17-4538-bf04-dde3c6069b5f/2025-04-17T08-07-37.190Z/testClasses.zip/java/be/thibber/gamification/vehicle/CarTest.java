package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.ArrayList;

public class CarTest {

    @Test
    public void carConstructorDefaultTest() {
        Person passenger1 = new Person("passenger1");
        ArrayList<Person> passengers = new ArrayList<>();
        passengers.add(passenger1);
        Car car = new Car(100, 4, passengers);
        assert car.getPassengers().contains(passenger1) && car.getPassengers().size() == 1;
        assert 100 == car.getSpeed();
        assert 4 == car.getSeatsCount();
    }

    @Test
    public void carConstructorNegativeSpeedTest() {
        try {
            Car car = new Car(-100, 4, new ArrayList<>());
        } catch (IllegalArgumentException e) {
            assert e.getMessage().equals("Speed must be greater than or equal to 0");
        }
    }

    @Test
    public void carConstructorWithoutSpeedTest() {
        Car car = new Car(4);
        assert car.getSpeed() == 0;
        assert car.getSeatsCount() == 4;
    }

    @Test
    public void carConstructorWithoutPassengersTest() {
        Car car = new Car(120, 4);
        assert car.getPassengers().isEmpty();
    }

    @Test
    public void addPassengerDefaultTest() {
        Car car = new Car(120, 4);
        assert car.getPassengers().isEmpty();
        Person passenger1 = new Person("passenger1");
        car.addPassenger(passenger1);
        assert car.getPassengers().size() == 1;
        Person passenger2 = new Person("passenger2");
        car.addPassenger(passenger2);
        assert car.getPassengers().size() == 2;
    }

    @Test
    public void addPassengerNullTest() {
        Car car = new Car(120, 4);
        assert car.getPassengers().isEmpty();
        Person passenger1 = null;
        try {
            car.addPassenger(passenger1);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }

    }

    @Test
    public void addPassengerTooMoreTest() {
        Car car = new Car(120, 1);
        assert car.getPassengers().isEmpty();
        Person passenger1 = new Person("passenger1");
        car.addPassenger(passenger1);
        assert car.getPassengers().size() == 1;
        Person passenger2 = new Person("passenger2");
        try {
            car.addPassenger(passenger2);
            assert false;
        } catch (IllegalStateException e) {
            assert true;
        }
    }

    @Test
    public void removePassengerDefaultTest() {
        Car car = new Car(120, 4);
        assert car.getPassengers().isEmpty();
        Person passenger1 = new Person("passenger1");
        car.addPassenger(passenger1);
        assert car.getPassengers().size() == 1;
        car.removePassenger(passenger1);
        assert car.getPassengers().isEmpty();
    }

    @Test
    public void removePassengerNullTest() {
        Car car = new Car(120, 4);
        assert car.getPassengers().isEmpty();
        Person passenger1 = new Person("passenger1");
        car.addPassenger(passenger1);
        assert car.getPassengers().size() == 1;
        try {
            car.removePassenger(null);
            assert false;
        } catch (IllegalArgumentException e) {
            assert true;
        }
    }

    @Test
    public void resetDefaultTest() {
        Person passenger1 = new Person("passenger1");
        ArrayList<Person> passengers = new ArrayList<>();
        passengers.add(passenger1);
        Car car = new Car(100, 4, passengers);

        assert car.getPassengers().size() == 1;
        assert car.getSpeed() == 100;
        car.reset();
        assert car.getPassengers().isEmpty();
        assert car.getSpeed() == 0;
    }

    @Test
    public void setSpeedWithoutPassengersTest() {
        Car car = new Car(120, 4);
        try {
            car.setSpeed(100);
            assert false;
        } catch (IllegalStateException e) {
            assert true;
        }
    }
}
