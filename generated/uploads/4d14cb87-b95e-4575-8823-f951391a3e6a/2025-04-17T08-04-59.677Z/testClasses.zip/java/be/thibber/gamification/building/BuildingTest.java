package be.thibber.gamification.building;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BuildingTest {

    Building ex_1building = new Building("Fac Info", 2.0, 4.0);
    Building ex_2building = new Building("BUMP", 3.0, 5.0);

    @Test
    public void getAddressTest() {
        assertEquals("Fac Info", ex_1building.getAddress());
        assertEquals("BUMP", ex_2building.getAddress());
    }
    @Test
    public void setAddressTest() {
        ex_1building.setAddress("Namur");
        ex_2building.setAddress("Pop up Bump");
        assertEquals("Namur", ex_1building.getAddress());
        assertEquals("Pop up Bump", ex_2building.getAddress());
    }


    @Test
    public void getGroundSurfaceTest() {
        assertEquals(2.0, ex_1building.getGroundSurface());
        assertEquals(3.0, ex_2building.getGroundSurface());
    }
    @Test
    public void setGroundSurfaceTest() {
        ex_1building.setGroundSurface(10.0);
        ex_2building.setGroundSurface(20.0);
        assertEquals(10.0, ex_1building.getGroundSurface());
        assertEquals(20.0, ex_2building.getGroundSurface());
    }



}
