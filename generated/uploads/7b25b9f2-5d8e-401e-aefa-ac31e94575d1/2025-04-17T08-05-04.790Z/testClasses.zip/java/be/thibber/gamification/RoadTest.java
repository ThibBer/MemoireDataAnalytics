package be.thibber.gamification;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class RoadTest {
    @Test
    public void testGetName() {
        Road road = new Road("Main Street", List.of(new Coords(0, 0), new Coords(1, 1)), List.of());
        assertEquals("Main Street", road.getName());
    }
}
