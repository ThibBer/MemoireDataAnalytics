package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class CarTest {
    List<Person> people = List.of(new Person("John Doe"));
    Car carNormal = new Car(60.0, 4, people);

    @Test
    public void testCarConstructor() {
        assertEquals(60.0, carNormal.getSpeed(), 0.01);
        assertEquals(4, carNormal.getSeatsCount());
        assertFalse(carNormal.getPassengers().isEmpty());
    }

    @Test
    public void testCarConstructorWithNegativeSpeed() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Car(-10.0, 4, people);
        });
    }

    @Test
    public void testCarConstructorDefault() {
        Car carDefault = new Car(4);
        assertEquals(0.0, carDefault.getSpeed(), 0.01);
        assertEquals(4, carDefault.getSeatsCount());
        assertTrue(carDefault.getPassengers().isEmpty());
    }

    @Test
    public void addPassenger() {
        Car car = new Car(4);
        Person person = new Person("Jane Doe");
        car.addPassenger(person);
        assertTrue(car.getPassengers().contains(person));
    }
}
