package be.thibber.gamification;

import be.thibber.gamification.building.Building;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class CityTest {

    @Test
    public void testBuilding() {

    }
}
