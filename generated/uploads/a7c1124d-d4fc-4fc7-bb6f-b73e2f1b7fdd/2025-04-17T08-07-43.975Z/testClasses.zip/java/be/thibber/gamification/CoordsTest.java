package be.thibber.gamification;

import org.junit.Test;

import static java.lang.Math.sqrt;

public class CoordsTest {

    @Test public void testX() {
        Coords c = new Coords(1,2);
        assert c.getX() == 1;
        c.setX(5);
        assert c.getX() == 5;

    }

    @Test public void testY() {
        Coords c = new Coords(1,2);
        assert c.getY() == 2;
        c.setY(6);
        assert c.getY() == 6;
    }

    @Test public void testDistance() {
        Coords c1 = new Coords(2,2);
        Coords c2 = new Coords(2,3);
        Coords c3 = new Coords(3,2);
        Coords c4 = new Coords(3,3);

        Coords negCoords1 = new Coords(-2,-2);
        Coords negCoords2 = new Coords(-2,-3);

        // 1 ditance on y axis
        assert c1.getDistanceTo(c2) == 1;

        // 1 distance on x axis
        assert c1.getDistanceTo(c3) == 1;

        // Same coords
        assert c1.getDistanceTo(c1) == 0;

        // Negative coords
        assert negCoords1.getDistanceTo(negCoords2) == 1;

        // Diag distance
        assert c1.getDistanceTo(c4) == sqrt(2);
    }

    @Test public void testAngle() {
        Coords c1 = new Coords(1,2);
        Coords c2 = new Coords(2,3);
        Coords c3 = new Coords(3,2);

        assert c1.getAngleTo(c1) == 0;
    }

    @Test public void testMove() {
        Coords c = new Coords(1,2);

        assert c.getX() == 1;
        assert c.getY() == 2;

        c.move(1,1);
        assert c.getX() == 2;
        assert c.getY() == 3;

        c.move(-3,-4);
        assert c.getX() == -1;
        assert c.getY() == -1;
    }
}