package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {
    @Test public void testPerson() {
        Person bob = new Person("Bob");

        assert bob.getName().equals("Bob");

        bob.setName("Jean-Marie Jacquet");
        assert bob.getName().equals("Jean-Marie Jacquet");
    }
}
