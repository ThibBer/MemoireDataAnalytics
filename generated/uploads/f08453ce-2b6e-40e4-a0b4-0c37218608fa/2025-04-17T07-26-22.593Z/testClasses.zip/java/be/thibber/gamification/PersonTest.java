package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {
    @Test
    public void testgetname(){}

    @Test
    public void testsetName(){}
}
