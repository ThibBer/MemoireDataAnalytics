package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    @Test
    public void coord_test() {
        Coords coord = new Coords(5, 7);
        assertEquals(5, coord.getX(),0.0);
        assertEquals(7, coord.getY(),0.0);
    }

    @Test
    public void set_coord_test() {
        Coords coord = new Coords(5, 7);
        coord.setX(4);
        coord.setY(6);
        assertEquals(4, coord.getX(),0.0);
        assertEquals(6, coord.getY(),0.0);
    }
}
