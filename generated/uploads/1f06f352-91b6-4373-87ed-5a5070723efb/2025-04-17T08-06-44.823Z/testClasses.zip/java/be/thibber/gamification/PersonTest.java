package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {
    @Test
    public void test_GetNamePerson() {

        //Set up
        Person jhon= new Person("Jhon");

        //Get the name
        String name= jhon.getName();

        //Verify
        assert  name.equals("Jhon");
    }

    @Test
    public void test_set_name(){
        //set up
        Person jhon= new Person("Jhon");

        //Set a new name
        jhon.setName("Jhonny");
        String name= jhon.getName();

        //Verify
        assert name.equals("Jhonny");
    }
}
