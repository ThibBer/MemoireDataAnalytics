package be.thibber.gamification;

import org.junit.Assert;
import org.junit.Test;

public class CoordsTest {
    @Test
    public void test_getX() {
        //Set up
        Coords coords = new Coords(5, 5);

        //Get the value
        double x_coord= coords.getX();

        //Verify
        assert x_coord==5;

    }

    @Test
    public void test_getY() {
        //Set up
        Coords coords = new Coords(5, 6);

        //Get the value
        double y_coord= coords.getY();

        //Verify
        assert y_coord==6;

    }

    @Test
    public void test_setX(){
        //Set up
        Coords coords = new Coords(5, 5);

        //Set the new value
        coords.setX(6);

        //Verify
        assert coords.getX()==6;
    }

    @Test
    public void test_setY(){
        //Set up
        Coords coords = new Coords(5, 5);

        //Set the new value
        coords.setY(6);

        //Verify
        assert coords.getY()==6;
    }

    @Test
    public void test_GetDistanceTo(){

        //Set up
        Coords coords1 = new Coords(5, 5);
        Coords coords2 = new Coords(5, 6);

        //Compute the distance
        double distance = coords1.getDistanceTo(coords2);

        //Verify
        assert distance==1;

    }

    @Test
    public void test_getAngleTo(){

        //Set up
        Coords coords1 = new Coords(5, 5);
        Coords coords2 = new Coords(5, 6);

        //compute the angle
        double angle = coords1.getAngleTo(coords2);

        //Verify
         assert angle==90;
    }

    @Test
    public void test_move(){
        //Set up
        Coords coords = new Coords(5, 5);

        //Move the coord
        coords.move(3,3);

        //Verify
        assert coords.getX()==8;
        assert coords.getY()==8;
    }
}
