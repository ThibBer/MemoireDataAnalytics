package be.thibber.gamification.building;

import be.thibber.gamification.vehicle.Car;
import  be.thibber.gamification.vehicle.Vehicle;
import org.junit.Test;

public class ParkingTest {

    @Test
    public void test_GetParkingCapacity() {
        //Set up
        Parking parking= new Parking("Parking",100,10);

        //Get the capacity of the parking
        double capacity = parking.getCapacity();

        //Verify
        assert capacity==10;
    }

    @Test
    public void test_SetParkingCapacity_belowZero() {
        //Set up
        Parking parking= new Parking("Parking",100,10);


        //Test that an error is triggered
        try{
            parking.setCapacity(-10);
        }
        catch(Exception e){
            assert e instanceof IllegalArgumentException;
        }
    }

    @Test
    public void Test_IsEmpty_good(){
        //Set up
        Parking parking= new Parking("Parking",100,10);

        //Verify
        assert parking.isEmpty();
    }

    @Test void Tets_IsEmpty_false(){
        //Set up
        Parking parking= new Parking("Parking",100,10);
        Vehicle vehicle=new Vehicle(30);

        //Add the car to the parking
        parking.addVehicle(vehicle);

        //Verify
        assert !parking.isEmpty();
    }
}
