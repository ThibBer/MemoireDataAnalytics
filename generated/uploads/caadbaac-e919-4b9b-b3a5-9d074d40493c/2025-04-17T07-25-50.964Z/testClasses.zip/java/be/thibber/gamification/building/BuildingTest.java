package be.thibber.gamification.building;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class BuildingTest {

    @Test
    public void testAddress(){
        Building building = new House("rue test", 100,2);
        assertEquals("rue test", building.getAddress());{
        }
    }
    @Test
    public void testAddressEmpty(){
        Building building = new House("", 100,2);
        assertEquals("", building.getAddress());{
        }
    }
    @Test
    public void testGroundSurface(){
        Building building = new House("rue test", 100,2);
        assertEquals(100, building.getGroundSurface(), 0.01);{
        }
    }
    @Test
    public void testGroundSurfaceNegatif(){
        Building building = new House("rue test", 100,2);
        assertThrows(IllegalArgumentException.class, () -> building.setGroundSurface(-1));{
        }
    }
    @Test
    public void testFloorsCount(){
        Building building = new House("rue test", 100,2);
        assertEquals(2, building.getFloorsCount(),0.1);{
        }
    }
    @Test
    public void testFloorsCountNull(){
        Building building = new House("rue test", 100,2);
        assertThrows(IllegalArgumentException.class, () -> building.setFloorsCount(0));{
        }
    }
    @Test
    public void testGetGroundSurface(){
        Building building = new House("rue test", 100,2);
        assertEquals(100, building.getGroundSurface(), 0.01);{
        }
    }


}
