package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.*;

public class VehicleTest {
    @Test
    public void testSpeedCreationNoParam(){
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
    }
    @Test
    public void testSpeedCreationWithParam(){
        Vehicle vehicle = new Vehicle(10);
        assertEquals(10, vehicle.getSpeed(), 0.01);
    }
    @Test
    public void testAccelerate(){
        Vehicle vehicle = new Vehicle(10);
        vehicle.accelerate(5);
        assertEquals(15, vehicle.getSpeed(), 0.01);
    }
    @Test
    public void testAccelerateNegative(){
        Vehicle vehicle = new Vehicle(10);
        assertThrows(IllegalArgumentException.class, () -> vehicle.accelerate(-1));
    }
    @Test
    public void testBrake(){
        Vehicle vehicle = new Vehicle(10);
        vehicle.brake(5);
        assertEquals(5, vehicle.getSpeed(), 0.01);
    }
    @Test
    public void testBrakeNegative(){
        Vehicle vehicle = new Vehicle(10);
        assertThrows(IllegalArgumentException.class, () -> vehicle.brake(-1));
    }
    @Test
    public void testIsStopped(){
        Vehicle vehicle = new Vehicle(0);
        assertTrue(vehicle.isStopped());
    }
    @Test
    public void testIsNotStopped(){
        Vehicle vehicle = new Vehicle(10);
        assertFalse(vehicle.isStopped());
    }
    @Test
    public void testReset(){
        Vehicle vehicle = new Vehicle(10);
        vehicle.reset();
        assertEquals(0, vehicle.getSpeed(), 0.01);
    }
}
