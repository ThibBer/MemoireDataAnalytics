package be.thibber.gamification;
import be.thibber.gamification.building.Building;
import be.thibber.gamification.building.Parking;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CityTest {

    static class TestBuilding extends Building {
        public TestBuilding(String address, double surface, double floors) {
            super(address, surface, floors);
        }
    }

    private City city = new City(new ArrayList<>(), new ArrayList<>());

    @Test
    public void testAddAndRemoveBuilding() {
        Building b = new TestBuilding("Rue de Bruxelles", 50, 2);
        city.addBuilding(b);
        assertEquals(1, city.countBuildingByType(Building.class));
        assertTrue(city.removeBuilding(b));
        assertEquals(0, city.countBuildingByType(Building.class));
    }






}
