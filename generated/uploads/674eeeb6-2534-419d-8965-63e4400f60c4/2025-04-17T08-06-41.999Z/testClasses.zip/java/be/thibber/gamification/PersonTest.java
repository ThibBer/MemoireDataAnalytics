package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;

public class PersonTest {

    @Test
    public void testConstructor() {
        Person person = new Person("Thomas");
        assertAll(
                ()-> assertTrue(person != null)
        );
    }

    @Test
    public void testGetName() {
        Person person = new Person("Thomas");
        assertAll(
                ()-> assertTrue(person.getName().equals("Thomas"))
        );
    }

    @Test
    public void testSetName() {
        Person person = new Person("Thomas");
        person.setName("Ilias");
        assertAll(
                ()-> assertTrue(person.getName().equals("Ilias"))
        );
    }
}
