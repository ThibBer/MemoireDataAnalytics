package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;


import static org.junit.jupiter.api.Assertions.assertAll;

public class CarTest {

}
