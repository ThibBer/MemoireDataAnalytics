package be.thibber.gamification.building;

import be.thibber.gamification.vehicle.Car;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ParkingTest {
    @Test
    public void parkingFull() {
        Parking parking = new Parking("LeVraiParking", 1, 1);
        Car car = new Car(4);
        assertTrue(parking.addVehicle(car));
    }
}
