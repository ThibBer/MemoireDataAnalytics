package be.thibber.gamification.building;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HouseTest {
    @Test
    public void getTotalSurfaceTest() {
        House house = new House("123 Main St", 100, 2);
        assertEquals(200, house.getTotalSurface(), 0.01);
    }
}
