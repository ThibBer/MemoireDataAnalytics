package be.thibber.gamification;

import be.thibber.gamification.example.Example;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;


public class CoordsTest {
    @Test
    public void getDistanceToTest(){
        Coords example = new Coords(10,10);
        Coords example2 = new Coords(10,11);
        assertEquals(1, example.getDistanceTo(example2));
    }
}
