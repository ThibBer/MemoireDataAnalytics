package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.*;

public class CoordsTest {
    @Test
    public void testDistanceTo() {
        Coords c1 = new Coords(0, 0);
        Coords c2 = new Coords(3, 4);
        double distance = c1.getDistanceTo(c2);

        assertEquals(5.0, distance, 0.0001);
    }
}
