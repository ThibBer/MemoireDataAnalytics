package be.thibber.gamification;

import be.thibber.gamification.vehicle.Vehicle;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class RoadTest {
    private Road road;
    private Vehicle vehicle1;
    private Vehicle vehicle2;
    private List<Coords> coordsList;

    private static class DummyVehicle extends Vehicle {
        // Classe vide pour simuler un véhicule
    }

    @Before
    public void setUp() {
        coordsList = new ArrayList<>();
        coordsList.add(new Coords(0, 0));
        coordsList.add(new Coords(1, 1));

        vehicle1 = new DummyVehicle();
        vehicle2 = new DummyVehicle();

        List<Vehicle> initialVehicles = new ArrayList<>();
        initialVehicles.add(vehicle1);

        road = new Road("Main Street", coordsList, initialVehicles);
    }

    @Test
    public void testGetName() {
        assertEquals("Main Street", road.getName());
    }

    @Test
    public void testSetName() {
        road.setName("Second Avenue");
        assertEquals("Second Avenue", road.getName());
    }

    @Test
    public void testGetVehicles() {
        List<Vehicle> vehicles = road.getVehicles();
        assertEquals(1, vehicles.size());
        assertTrue(vehicles.contains(vehicle1));
    }

    @Test
    public void testAddVehicle() {
        road.addVehicle(vehicle2);
        assertEquals(2, road.getVehicles().size());
        assertTrue(road.getVehicles().contains(vehicle2));
    }

    @Test
    public void testRemoveVehicle() {
        road.removeVehicle(vehicle1);
        assertEquals(0, road.getVehicles().size());
        assertFalse(road.getVehicles().contains(vehicle1));
    }
}