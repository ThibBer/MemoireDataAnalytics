package be.thibber.gamification;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import be.thibber.gamification.building.Building;
import be.thibber.gamification.building.House; // Assurez-vous que House est importé
import be.thibber.gamification.building.Parking; // Assurez-vous que Parking est importé
import be.thibber.gamification.Road;
import be.thibber.gamification.City;
import be.thibber.gamification.Coords;  // Assurez-vous que Coords est importé
import be.thibber.gamification.vehicle.Vehicle;  // Assurez-vous que Vehicle est importé

public class CityTest {
    private City city;
    private Building building1, building2;
    private Road road1, road2;

    @Before
    public void setUp() {
        // Création des bâtiments
        building1 = new House("Building 1", 100.0, 10.0);
        building2 = new House("Building 2", 200.0, 15.0);

        // Création des coordonnées pour les routes
        Coords point1 = new Coords(0, 0);
        Coords point2 = new Coords(5, 5);
        List<Coords> roadPoints = Arrays.asList(point1, point2);

        // Création d'une liste de véhicules (vous pouvez laisser vide pour l'instant)
        List<Vehicle> vehicles = Arrays.asList(); // Pas de véhicules pour ce test

        // Instanciation des routes avec les bons arguments
        road1 = new Road("Road 1", roadPoints, vehicles);
        road2 = new Road("Road 2", roadPoints, vehicles);

        // Création de la ville avec les bâtiments et les routes
        city = new City(Arrays.asList(building1, building2), Arrays.asList(road1, road2));
    }

    @Test
    public void testAddBuilding() {
        // Ajout d'un nouveau bâtiment
        House building3 = new House("Building 3", 150.0, 12.0);
        city.addBuilding(building3);

        // Vérifier l'ajout en utilisant la méthode removeBuilding pour valider si le bâtiment est présent
        city.removeBuilding(building3);
        assertFalse("Building should be removed.", city.getBuildings().contains(building3));
    }

    @Test
    public void testRemoveBuilding() {
        // Suppression d'un bâtiment de la ville
        city.removeBuilding(building1);

        // Vérification via une manipulation directe (si vous avez une méthode qui modifie la ville)
        assertFalse("Building should be removed.", city.getBuildings().contains(building1));
    }

    @Test
    public void testGetBuildingsGroundSurface() {
        double surface = city.getBuildingsGroundSurface();
        assertEquals("Total building surface should be 300.", 300.0, surface, 0.01);
    }

    @Test
    public void testCountBuildingByType() {
        int parkingCount = city.countBuildingByType(Parking.class);
        assertEquals("There should be no parking in the city.", 0, parkingCount);
    }

    @Test
    public void testGetAvailableParkingSlotsCount() {
        int availableParking = city.getAvailableParkingSlotsCount();
        assertEquals("There should be no available parking.", 0, availableParking);
    }

    @Test
    public void testGetAverageRoadLength() {
        double avgLength = city.getAverageRoadLength();
        assertEquals("Average road length should be 15.", 15.0, avgLength, 0.01);
    }
}
