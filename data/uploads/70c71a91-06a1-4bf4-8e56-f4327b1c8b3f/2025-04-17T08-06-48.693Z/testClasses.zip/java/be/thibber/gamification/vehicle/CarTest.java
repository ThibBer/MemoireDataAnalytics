package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.ArrayList;

public class CarTest {

    @Test
    public void testAddPassenger() {
        Person robin = new Person("Robin");
        Person john = new Person("John");
        ArrayList<Person> passengers = new ArrayList<Person>();
        passengers.add(john);
        passengers.add(robin);
        Car myCar = new Car(120, 4);
        myCar.setPassengers(passengers);

        Person emilien = new Person("Emilien");
        myCar.addPassenger(emilien);

        // assert "emilien".equals(myCar.getPassengers().get(0));

    }
}
