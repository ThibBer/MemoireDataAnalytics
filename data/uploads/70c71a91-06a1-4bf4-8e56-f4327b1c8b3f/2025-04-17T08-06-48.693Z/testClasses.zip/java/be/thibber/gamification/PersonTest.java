package be.thibber.gamification;

import org.junit.Test;

public class PersonTest {

    @Test
    public void testGetName() {
        Person robin = new Person("Robin");
        assert "Robin".equals(robin.getName());
    }


    @Test
    public void testSetName() {
        Person robin = new Person("Robin");
        robin.setName("John");
        assert "John".equals(robin.getName());
    }

}
