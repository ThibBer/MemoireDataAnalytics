package be.thibber.gamification;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class CoordsTest {

    @Test
    public void getXTest() {
        Coords coords = new Coords(5, 9);
        assert 5 == coords.getX();
    }

    @Test
    public void getYTest() {
        Coords coords = new Coords(5, 9);
        // assertEquals(9, coords.getY());
        assert 9 == coords.getY();

    }

    @Test
    public void setXTest() {
        Coords coords = new Coords(5, 9);

        coords.setX(-1);
        // assertEquals(20, coords.getX());
        assert -1 == coords.getX();

    }

    @Test
    public void setYTest() {
        Coords coords = new Coords(5, -5);

        coords.setY(2);
        //assertEquals(-5, coords.getY());
        assert 2 == coords.getY();


    }

    @Test
    public void getDistanceTest() {
        Coords coords1 = new Coords(1, 1);
        Coords coords2 = new Coords(5, 4);


        // assertEquals(5, coords1.getDistanceTo(coords2));
        assert 5 == coords1.getDistanceTo(coords2);
        // System.out.println(coords1.getDistanceTo(coords2));



    }
}
