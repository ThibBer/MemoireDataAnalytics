package be.thibber.gamification;
import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class PersonTest {

    @Test
    public void ifExists() {
        Example example = new Example();
        assertEquals(15, example.sum(10, 5));
        assertEquals(0, example.sum(0, 0));
    }
}
