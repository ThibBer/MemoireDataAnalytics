package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    @Test
    public void getDistanceToTest{

        Coords coords = new Coords(2,3);
        assertEquals(8,Coords.getDistanceTo(2,3));
        assertEquals(0,Coords.getDistanceTo(0,0));


    }



}
