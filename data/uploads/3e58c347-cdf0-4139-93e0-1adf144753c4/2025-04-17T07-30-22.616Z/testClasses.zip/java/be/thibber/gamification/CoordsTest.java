package be.thibber.gamification;

//import be.thibber.gamification.example.Example;
import be.thibber.gamification.Coords.getDistanceTo;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void getDistanceToTest{

        Coords coords = new Coords();
        assertEquals(8,Coords.getDistanceTo(2,3));
        assertEquals(0,Coords.getDistanceTo(0,0));


    }



}
