package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;


public class CoordsTest {

    @Test
    public void getDistanceToTest(){

        Coords coords = new Coords(2,3);
        Coords coord = new Coords(0,0);
        //assertEquals(8,coords.getDistanceTo(coords));
        assertEquals(0,coords.getDistanceTo(coord));


    }



}
