package be.thibber.gamification.building;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class HouseTest {
    @Test
    public void testSurface() {
        House house = new House("rue test", 100, 2);
        assertEquals(200, house.getTotalSurface(), 0.01);
    }
}
