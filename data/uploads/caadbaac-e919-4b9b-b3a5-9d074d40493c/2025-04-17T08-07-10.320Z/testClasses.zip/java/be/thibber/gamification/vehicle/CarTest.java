package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class CarTest {
    @Test
    public void testCarCreationOneParam(){
        Car car = new Car(0);
        assertEquals(0, car.getSpeed(), 0.01);
        assertEquals(0,car.getSeatsCount(), 0.01);
        assertEquals(0,car.getPassengers().size(), 0.01);
    }
    @Test
    public void testCarSetSeatsCount(){
        Car car = new Car(0);
        car.setSeatsCount(5);
        assertEquals(5, car.getSeatsCount(), 0.01);
    }
    @Test
    public void testCarSetSeatNegative(){
        Car car = new Car(0);
        assertThrows(IllegalArgumentException.class, () -> car.setSeatsCount(-1));
    }
    @Test
    public void testAddPassenger(){
        Car car = new Car(5);
        Person person = new Person("John");
        car.addPassenger(person);
        assertEquals(1, car.getPassengers().size(), 0.01);
    }
    @Test
    public void testAddPassengerNull(){
        Car car = new Car(0);
        car.setSeatsCount(5);
        assertThrows(IllegalArgumentException.class, () -> car.addPassenger(null));
    }
    @Test
    public void testRemovePassenger(){
        Car car = new Car(5);
        Person person = new Person("John");
        car.addPassenger(person);
        car.removePassenger(person);
        assertEquals(0, car.getPassengers().size(), 0.01);
    }
    @Test
    public void testRemovePassengerNull(){
        Car car = new Car(0);
        car.setSeatsCount(5);
        assertThrows(IllegalArgumentException.class, () -> car.removePassenger(null));
    }
}
