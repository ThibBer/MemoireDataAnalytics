package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void testSetX() {
        Coords coords = new Coords(1,1);
        coords.setX(10);
        assertEquals(10, coords.getX(), 0.01);
    }
}
