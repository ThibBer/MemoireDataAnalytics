package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {
    @Test
    public void coordTest() {
        Coords coords = new Coords(10, 5);
        assertEquals(coords.getX(), 10.0, 0.0);
        assertEquals(coords.getY(), 5.0, 0.0);
    }

    @Test
    public void disttest() {
        Coords coord1 = new Coords(10, 5);
        Coords coord2 = new Coords(5, 5);
        assertEquals(25, coord1.getDistanceTo(coord2), 0.0);
    }

    @Test
    public void angleTest() {
        Coords coord1 = new Coords(10, 5);
        Coords coord2 = new Coords(10, 10);
        assertEquals(90, coord1.getAngleTo(coord2), 0.0);
    }
}
