package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.*;

public class VehicleTest {
    @Test
    public void canInstantiateVehicle() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void canInstantiateVehicleWithSpeed() {
        Vehicle vehicle = new Vehicle(10);
        assertEquals(10, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void canSetSpeed() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        vehicle.setSpeed(20);
        assertEquals(20, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void cannotSetNegativeSpeed() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        assertThrows(IllegalArgumentException.class, () -> vehicle.setSpeed(-10));
    }

    @Test
    public void canAccelerate() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        vehicle.accelerate(10);
        assertEquals(10, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void cannotAccelerateNegative() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        assertThrows(IllegalArgumentException.class, () -> vehicle.accelerate(-10));
    }

    @Test
    public void canBrake() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        vehicle.accelerate(20);
        assertEquals(20, vehicle.getSpeed(), 0.01);
        vehicle.brake(10);
        assertEquals(10, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void cannotBrakeBelowZero() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        vehicle.accelerate(20);
        assertEquals(20, vehicle.getSpeed(), 0.01);
        vehicle.brake(30);
        assertEquals(0, vehicle.getSpeed(), 0.01);
    }

    @Test
    public void cannotBrakeNegative() {
        Vehicle vehicle = new Vehicle();
        assertEquals(0, vehicle.getSpeed(), 0.01);
        vehicle.accelerate(20);
        assertEquals(20, vehicle.getSpeed(), 0.01);
        assertThrows(IllegalArgumentException.class, () -> vehicle.brake(-10));
    }

    @Test
    public void isStoppedTest() {
        Vehicle vehicle = new Vehicle();
        assertTrue(vehicle.isStopped());
        vehicle.accelerate(10);
        assertFalse(vehicle.isStopped());
        vehicle.brake(10);
        assertTrue(vehicle.isStopped());
    }

    @Test
    public void resetTest() {
        Vehicle vehicle = new Vehicle();
        vehicle.accelerate(10);
        assertFalse(vehicle.isStopped());
        vehicle.reset();
        assertTrue(vehicle.isStopped());
    }
}
