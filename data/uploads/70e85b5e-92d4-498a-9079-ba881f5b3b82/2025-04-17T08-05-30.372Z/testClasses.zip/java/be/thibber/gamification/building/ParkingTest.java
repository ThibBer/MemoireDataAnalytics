package be.thibber.gamification.building;

import be.thibber.gamification.exceptions.FullParkingException;
import be.thibber.gamification.vehicle.Vehicle;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class ParkingTest {
    @Test
    public void canInstantiateParkingTest() {
        Parking parking = new Parking("Cathédrale", 203.8, 100);
        assertNotNull(parking);
    }

    @Test
    public void canInstantiateParkingWithVehiclesTest() {
        Vehicle vehicle = new Vehicle(120);
        Parking parking = new Parking("Cathédrale", 203.8, 1, List.of(vehicle));
        assertNotNull(parking);
        assertTrue(parking.isFull());
    }

    @Test
    public void getCapacityTest() {
        Parking parking = new Parking("Cathédrale", 203.8, 100);
        assertEquals(100, parking.getCapacity());
    }

    @Test
    public void setCapacityTest() {
        Parking parking = new Parking("Cathédrale", 203.8, 100);
        parking.setCapacity(200);
        assertEquals(200, parking.getCapacity());
    }

    @Test
    public void addVehicleTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 100);
        Vehicle vehicle = new Vehicle(120);
        parking.addVehicle(vehicle);
    }

    @Test
    public void fullParkingTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 1);
        Vehicle vehicle = new Vehicle(120);
        assertFalse(parking.isFull());
        parking.addVehicle(vehicle);
        assertTrue(parking.isFull());
    }

    @Test
    public void emptyParkingTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 1);
        Vehicle vehicle = new Vehicle(120);
        assertTrue(parking.isEmpty());
        parking.addVehicle(vehicle);
        assertFalse(parking.isEmpty());
        parking.removeVehicle(vehicle);
        assertTrue(parking.isEmpty());
    }

    @Test
    public void alreadyFullParkingTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 1);
        Vehicle vehicle = new Vehicle(120);
        parking.addVehicle(vehicle);
        assertThrows(FullParkingException.class, () -> {
            parking.addVehicle(vehicle);
        });
    }

    @Test
    public void getAvailableSpotsTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 2);
        Vehicle vehicle = new Vehicle(120);
        assertEquals(2, parking.getAvailableSpots());
        parking.addVehicle(vehicle);
        assertEquals(1, parking.getAvailableSpots());
        parking.addVehicle(vehicle);
        assertEquals(0, parking.getAvailableSpots());
    }

    @Test
    public void removeVehicleTest() throws FullParkingException {
        Parking parking = new Parking("Cathédrale", 203.8, 1);
        Vehicle vehicle = new Vehicle(120);
        parking.addVehicle(vehicle);
        parking.removeVehicle(vehicle);
        assertTrue(parking.isEmpty());
    }
}
