package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertNotNull;

public class CarTest {
    @Test
    public void canInstantiateCar() {
        Car car = new Car(7);
        assertNotNull(car);
    }

    @Test
    public void canInstantiateCarWithSpeed() {
        Car car = new Car(10, 5);
        assertNotNull(car);
    }

    @Test
    public void canInstantiateCarWithSpeedAndSeatsAndPassengers() {
        Person passenger = new Person("John Doe");
        Car car = new Car(10, 5, List.of(passenger));
        assertNotNull(car);
    }
}
