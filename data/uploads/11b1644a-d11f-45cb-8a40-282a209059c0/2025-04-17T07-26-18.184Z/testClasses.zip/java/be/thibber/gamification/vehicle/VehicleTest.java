package be.thibber.gamification.vehicle;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertThrows;

public class VehicleTest {
    @Test
    public void test_vehicle_zero_speed() {
        Vehicle v = new Vehicle();

        Assert.assertEquals(0.0, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_zero_speed_01() {
        Vehicle v = new Vehicle(0);

        Assert.assertEquals(0.0, v.getSpeed(), 0.1);
    }


    @Test
    public void test_vehicle_set_negative_speed() {
        Vehicle v = new Vehicle(10);


        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            v.setSpeed(-10);
        });

        Assert.assertTrue(exception.getMessage().contains("Speed must be greater than or equal to 0"));
    }


    @Test
    public void test_vehicle_set_zero_speed() {
        Vehicle v = new Vehicle(10);

        v.setSpeed(0);

        Assert.assertEquals(0.0, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_set_speed() {
        Vehicle v = new Vehicle(10);

        v.setSpeed(30);

        Assert.assertEquals(30.0, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_acceleration() {
        Vehicle v = new Vehicle(10);

        v.accelerate(10);

        Assert.assertEquals(20.0, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_acceleration_negative_speed() {
        Vehicle v = new Vehicle(10);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            v.accelerate(-10);
        });

        Assert.assertTrue(exception.getMessage().contains("Increment must be positive"));
    }

    @Test
    public void test_vehicle_acceleration_zero_speed() {
        Vehicle v = new Vehicle(10);

        v.accelerate(0);

        Assert.assertEquals(10, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_stop_false() {
        Vehicle v = new Vehicle(10);

        Assert.assertFalse(v.isStopped());
    }

    @Test
    public void test_vehicle_stop_true() {
        Vehicle v = new Vehicle(10);

        v.setSpeed(0);

        Assert.assertTrue(v.isStopped());
    }

    @Test
    public void test_vehicle_reset() {
        Vehicle v = new Vehicle(10);

        v.reset();

        Assert.assertEquals(0, v.getSpeed(), 0.1);
        Assert.assertTrue(v.isStopped());
    }

    @Test
    public void test_vehicle_brake() {
        Vehicle v = new Vehicle(10);

        v.brake(10);

        Assert.assertEquals(0.0, v.getSpeed(), 0.1);
    }

    @Test
    public void test_vehicle_brake_positive_speed() {
        Vehicle v = new Vehicle(10);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            v.brake(-10);
        });

        Assert.assertTrue(exception.getMessage().contains("Decrement must be positive"));
    }

    @Test
    public void test_vehicle_brake_zero_speed() {
        Vehicle v = new Vehicle(10);

        v.brake(0);

        Assert.assertEquals(10, v.getSpeed(), 0.1);
    }

}
