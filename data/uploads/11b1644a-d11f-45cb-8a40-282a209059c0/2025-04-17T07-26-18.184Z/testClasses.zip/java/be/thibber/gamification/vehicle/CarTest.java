package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class CarTest {
    @Test
    public void test() {
        // Car c = new Car(10,5, List.of(new Person("Hugo")));
        Assert.assertTrue(true);
    }
}
