package be.thibber.gamification;

import org.junit.Assert;
import org.junit.Test;

public class PersonTest {
    @Test
    public void test_name() {
        Person p = new Person("Hugo");
        Assert.assertEquals("Hugo", p.getName());
    }

    @Test
    public void test_name_empty() {
        Person p = new Person("");
        Assert.assertEquals("", p.getName());
    }

    @Test
    public void test_name_null() {
        Person p = new Person(null);
        Assert.assertNull(p.getName());
    }

    @Test
    public void test_set_name() {
        Person p = new Person("Hugo");
        p.setName("Theo");

        Assert.assertEquals("Theo", p.getName());
    }

    @Test
    public void test_set_name_empty() {
        Person p = new Person("Hugo");
        p.setName("");

        Assert.assertEquals("", p.getName());
    }

    @Test
    public void test_set_name_null() {
        Person p = new Person("Hugo");
        p.setName(null);
        Assert.assertNull(p.getName());
    }
}
