package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CoordsTest {

    @Test
    public void coord_test() {
        Coords coord = new Coords(5, 7);
        assertEquals(5, coord.getX(),0.0);
        assertEquals(7, coord.getY(),0.0);
    }

    @Test
    public void set_coord_test() {
        Coords coord = new Coords(5, 7);
        coord.setX(4);
        coord.setY(6);
        assertEquals(4, coord.getX(),0.0);
        assertEquals(6, coord.getY(),0.0);
    }

    @Test
    public void get_distance_test() {
        Coords coord = new Coords(5, 7);
        Coords autre = new Coords(15, 7);
        assertEquals(10, coord.getDistanceTo(autre), 0.0);
    }

    @Test
    public void get_angle_test() {
        Coords coord = new Coords(10, 10);
        Coords autre = new Coords(5, 5);
        assertEquals(-135, coord.getAngleTo(autre), 0.0);
    }

    @Test
    public void move_test() {
        Coords coord = new Coords(10, 10);
        assertEquals(10, coord.getX(),0.0);
        assertEquals(10, coord.getY(),0.0);
        coord.move(14,72);
        assertEquals(24,coord.getX(),0.0);
        assertEquals(82,coord.getY(),0.0);
    }
}
