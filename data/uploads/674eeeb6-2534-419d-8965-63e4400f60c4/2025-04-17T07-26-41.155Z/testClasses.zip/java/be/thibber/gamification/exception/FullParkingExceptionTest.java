package be.thibber.gamification.exception;

public class FullParkingExceptionTest {
}
