package be.thibber.gamification;

import org.junit.Test;

import static org.junit.Assert.assertTrue;


import static org.junit.jupiter.api.Assertions.assertAll;
public class CoordsTest {

    @Test
    public void testConstructor() {
        Coords coordTest = new Coords(2,3);
        assertAll(
                ()-> assertTrue(coordTest.getX() == 2),
                ()-> assertTrue(coordTest.getY() == 3)
        );
    }

    @Test
    public void testUpdateCoords() {
        Coords coordTest = new Coords(1,2);
        coordTest.setX(2);
        coordTest.setY(3);
        assertAll(
                ()-> assertTrue(coordTest.getX() == 2),
                ()-> assertTrue(coordTest.getY() == 3)
        );
    }

    @Test
    public void testMoveCoord() {
        Coords coordTest = new Coords(2,3);
        coordTest.move(5,5);
        assertAll(
                ()-> assertTrue(coordTest.getX() == 7),
                ()-> assertTrue(coordTest.getY() == -2)
        );
    }

    @Test
    public void testSetX() {
        Coords coordTest = new Coords(2,3);
        coordTest.setX(3);
        assertAll(
                ()-> assertTrue(coordTest.getX() == 3)
        );
    }
    @Test
    public void testSetY() {
        Coords coordTest = new Coords(2,3);
        coordTest.setY(4);
        assertAll(
                ()-> assertTrue(coordTest.getY() == 4)
        );
    }

    @Test
    public void testGetX() {
        Coords coordTest = new Coords(2,3);
        assertAll(
                ()-> assertTrue(coordTest.getX() == 2)
        );
    }


    @Test
    public void testGetY() {
        Coords coordTest = new Coords(2,3);
        assertAll(
                ()-> assertTrue(coordTest.getY() == 3)
        );
    }

    @Test
    public void testgetAngleTo() {
        Coords testCoord = new Coords(2,2);
        Coords testCoordFct = new Coords(1,1);

        testCoord.getAngleTo(testCoordFct);
        assertAll(
                ()-> assertTrue(testCoord.getX() != 0),
                ()-> assertTrue(testCoord.getY() != 0)
        );
    }
}
