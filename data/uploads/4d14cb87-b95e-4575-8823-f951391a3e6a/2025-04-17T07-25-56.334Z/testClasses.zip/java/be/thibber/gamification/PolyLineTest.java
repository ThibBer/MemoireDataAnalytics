package be.thibber.gamification;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PolyLineTest {
    @Test
    public void double getLengthTest() {
        PolyLine pol_ex = new PolyLine() {};
        assertEquals(15, example.sum(10, 5));
        assertEquals(0, example.sum(0, 0));
    }
}
