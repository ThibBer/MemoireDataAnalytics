package be.thibber.gamification.building;

import be.thibber.gamification.example.Example;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BuildingTest {
    @Test
    public void getAddressTest("Fac Info", double groundSurface, double floorsCount) {
        Building ex_1building = new Building(address, groundSurface, floorsCount);
        Building ex_2building = new Building(address, groundSurface, floorsCount);
        assertEquals(15, example.sum(10, 5));
        assertEquals(0, example.sum(0, 0));
    }
}
