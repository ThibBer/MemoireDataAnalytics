package be.thibber.gamification.vehicle;

import be.thibber.gamification.Person;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class CarTest {
    @Test
    public void testCarResetSpeed() {
        Person examplePerson1 = new Person("John");
        Person examplePerson2 = new Person("Doe");

        ArrayList<Person> passengers = new ArrayList<Person>();
        passengers.add(examplePerson1);
        passengers.add(examplePerson2);


        Car exampleCar = new Car(10, 5, passengers);

        exampleCar.reset();
        assertEquals(0, exampleCar.getSpeed());
        
    }
}
