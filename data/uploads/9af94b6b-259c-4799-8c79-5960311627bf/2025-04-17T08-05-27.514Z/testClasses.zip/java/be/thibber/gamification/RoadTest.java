package be.thibber.gamification;

import be.thibber.gamification.vehicle.Vehicle;


import java.util.ArrayList;
import java.util.List;


public class RoadTest {

    @Test
    public void testNomDeLaRoute() {
        List<Coords> points = new ArrayList<>();
        List<Vehicle> vehicules = new ArrayList<>();
        Road road = new Road("Route Nationale", points, vehicules);

        // On vérifie que le nom est bien celui qu'on a mis
        assertEquals("Route Nationale", road.getName());
    }

    @Test
    public void testAjoutVehicule() {
        List<Coords> points = new ArrayList<>();
        List<Vehicle> vehicules = new ArrayList<>();
        Road road = new Road("Route", points, vehicules);

        Vehicle v1 = new Vehicle("V1"); // Tu dois adapter selon ton constructeur
        road.addVehicle(v1);

        // On vérifie que le véhicule a bien été ajouté
        assertTrue(road.getVehicles().contains(v1));
        assertEquals(1, road.getVehicles().size());
    }

    @Test
    public void testSuppressionVehicule() {
        List<Coords> points = new ArrayList<>();
        List<Vehicle> vehicules = new ArrayList<>();
        Vehicle v1 = new Vehicle("V1");
        vehicules.add(v1);

        Road road = new Road("Route", points, vehicules);
        road.removeVehicle(v1);

        // On vérifie que le véhicule a bien été supprimé
        assertFalse(road.getVehicles().contains(v1));
        assertEquals(0, road.getVehicles().size());
    }
}