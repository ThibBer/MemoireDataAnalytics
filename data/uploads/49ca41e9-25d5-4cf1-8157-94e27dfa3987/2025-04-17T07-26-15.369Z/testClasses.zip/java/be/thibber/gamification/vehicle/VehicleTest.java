package be.thibber.gamification.vehicle;

import org.junit.Test;

import static org.junit.Assert.*;

public class VehicleTest {
    private Class<T> IllegalArgumentException;

    @Test
    public void test1()
    {
        Vehicle VehiculeTest = new Vehicle(1);
        boolean valuetest = VehiculeTest.isStopped();
        assertFalse(valuetest);
    }

    @Test
    public void test2()
    {
        Vehicle VehiculeTest = new Vehicle(5);
        double valuetest2 = VehiculeTest.getSpeed();
        assertEquals(5,valuetest2);

    }

    @Test
    public void test1b()
    {
        Vehicle VehiculeTest = new Vehicle(0);
        boolean valuetest = VehiculeTest.isStopped();
        assertTrue(valuetest);
    }

    @Test
    public void test1c()
    {
        Vehicle VehiculeTest = new Vehicle(-5);
        assertThrows(IllegalArgumentException,VehiculeTest);
    }

    @Test
    public void test1d()
    {
        Vehicle VehiculeTest = new Vehicle(-5);
        assertThrows(IllegalArgumentException,VehiculeTest;
    }
}
