package be.thibber.gamification.building;

public class HouseTest {
}
