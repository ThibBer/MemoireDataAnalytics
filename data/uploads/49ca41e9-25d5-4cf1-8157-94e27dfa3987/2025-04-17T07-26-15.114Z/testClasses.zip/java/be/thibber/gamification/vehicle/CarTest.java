package be.thibber.gamification.vehicle;
import be.thibber.gamification.Person;

public class CarTest {
    public Person testensemble = new Person("ok");
    @Test
    public void testinitialisation()
    {

    }
}
