package be.thibber.gamification;
import be.thibber.gamification.vehicle.Vehicle;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class RoadTest {

    @Test
    public void getVehicleTest() {
        List<Vehicle> emptyList = new List();
        Coords testcoordinates = new Coords(1,1);
        Road test = new Road("route1",testcoordinates,emptyList);
        Vehicle test1 = new Vehicle();
        test.addVehicle(test1);
        assertEqual(test1, test.getVehicles());
        test.removeVehicle(test1);
       assertEqual(null, test.getVehicles());


    }
}
